use crate::net_app::model::{NETAPP_STATE, PortBusinessInfo};
use crate::net_app::utils::*;
use std::process::Command;
use chrono::Utc;

pub fn update_netstat_info() {
    let output = Command::new("sh")
        .arg("-c")
        .arg("netstat -tnlp | grep tcp")
        .output();

    let now = Utc::now().timestamp();
    let mut map = NETAPP_STATE.write().unwrap();
    map.port_map.clear();
    map.port_str_map.clear();

    if let Ok(out) = output {
        if out.status.success() {
            let content = String::from_utf8_lossy(&out.stdout);
            for line in content.lines() {
                let tokens: Vec<&str> = line.split_whitespace().collect();
                if tokens.len() < 7 {
                    continue;
                }

                let protocol = tokens[0].to_string();
                let local = tokens[3];
                let remote = tokens[4];
                let status = tokens[5];
                let process = tokens[6];

                let (local_ip, local_port) = split_ip_port(local);
                let (remote_ip, remote_port) = split_ip_port(remote);
                let remote_port = remote_port.to_string();
                let (pid, path) = parse_pid_path(process);

                let info = PortBusinessInfo {
                    time: now,
                    protocol,
                    local_ip,
                    local_port,
                    remote_ip,
                    remote_port,
                    status: status.to_string(),
                    pid,
                    process_path: path,
                };

                map.port_map.insert(info.local_port, info.clone());
                map.port_str_map.insert(local.to_string(), info);
            }
            return;
        }
    }

    // fallback to /proc/net/tcp
    parse_proc_net_tcp("/proc/net/tcp");
    parse_proc_net_tcp("/proc/net/tcp6");
}

fn parse_proc_net_tcp(file: &str) {
    use std::fs::File;
    use std::io::{BufRead, BufReader};

    let now = Utc::now().timestamp();
    if let Ok(f) = File::open(file) {
        let reader = BufReader::new(f);
        let mut lines = reader.lines();

        lines.next(); // skip header

        let mut map = NETAPP_STATE.write().unwrap();

        for line in lines.flatten() {
            let cols: Vec<&str> = line.split_whitespace().collect();
            if cols.len() < 10 {
                continue;
            }

            let (local_ip, local_port) = hex_to_ip_port(cols[1]);
            let (remote_ip, remote_port) = hex_to_ip_port(cols[2]);
            let status = proc_net_status_to_str(cols[3]).to_string();

            let info = PortBusinessInfo {
                time: now,
                protocol: "tcp".into(),
                local_ip,
                local_port: local_port.parse().unwrap_or(0),
                remote_ip,
                remote_port,
                status,
                pid: 0,
                process_path: "--".into(),
            };

            map.port_map.insert(info.local_port, info.clone());
            map.port_str_map.insert(cols[1].to_string(), info);
        }
    }
}

fn split_ip_port(addr: &str) -> (String, u16) {
    if let Some(idx) = addr.rfind(':') {
        let ip = &addr[..idx];
        let port = addr[idx+1..].parse().unwrap_or(0);
        (ip.to_string(), port)
    } else {
        ("0.0.0.0".into(), 0)
    }
}

fn parse_pid_path(proc: &str) -> (i32, String) {
    if let Some(idx) = proc.find('/') {
        let pid_str = &proc[..idx];
        if let Ok(pid) = pid_str.parse() {
            return (pid, format!("/proc/{}/exe", pid));
        }
    }
    (0, "--".into())
}

