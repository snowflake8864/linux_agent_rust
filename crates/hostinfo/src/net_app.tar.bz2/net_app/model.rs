use std::collections::HashMap;
use std::sync::{Arc, RwLock};
use std::fmt;
use logging::log_info;

#[derive(Debug, Clone)]
pub struct PortBusinessInfo {
    pub time: i64,
    pub protocol: String,
    pub local_ip: String,
    pub local_port: u16,
    pub remote_ip: String,
    pub remote_port: String,
    pub status: String,
    pub pid: i32,
    pub process_path: String,
}

// 为 PortBusinessInfo 实现 Display trait 以便更好地打印
impl fmt::Display for PortBusinessInfo {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "PortBusinessInfo {{ local_port: {}, protocol: {}, local_ip: {}, remote_ip: {}, status: {}, pid: {} }}", 
               self.local_port, self.protocol, self.local_ip, self.remote_ip, self.status, self.pid)
    }
}

#[derive(Default, Debug)]
pub struct NetAppState {
    pub port_map: HashMap<u16, PortBusinessInfo>,
    pub port_str_map: HashMap<String, PortBusinessInfo>,
}

impl NetAppState {
    // 添加打印方法
    pub fn print_contents(&self) {
        log_info!("=== NetAppState Contents ===");
        println!("port_map ({} entries):", self.port_map.len());
        for (port, info) in &self.port_map {
            log_info!("  {}: {}", port, info);
        }
        
        println!("port_str_map ({} entries):", self.port_str_map.len());
        for (key, info) in &self.port_str_map {
            log_info!("  {}: {}", key, info);
        }
        log_info!("==========================");
    }
    
    // 获取内容的字符串表示
    pub fn get_contents_string(&self) -> String {
        let mut result = String::new();
        result.push_str(&format!("=== NetAppState Contents ===\n"));
        result.push_str(&format!("port_map ({} entries):\n", self.port_map.len()));
        for (port, info) in &self.port_map {
            result.push_str(&format!("  {}: {}\n", port, info));
        }
        
        result.push_str(&format!("port_str_map ({} entries):\n", self.port_str_map.len()));
        for (key, info) in &self.port_str_map {
            result.push_str(&format!("  {}: {}\n", key, info));
        }
        result.push_str(&format!("==========================\n"));
        result
    }
    
    // 获取特定端口信息
    pub fn get_port_info(&self, port: u16) -> Option<&PortBusinessInfo> {
        self.port_map.get(&port)
    }
    
    // 获取所有端口信息
    pub fn get_all_port_info(&self) -> Vec<&PortBusinessInfo> {
        self.port_map.values().collect()
    }
    
    // 添加端口信息
    pub fn add_port_info(&mut self, port: u16, info: PortBusinessInfo) {
        self.port_map.insert(port, info.clone());
        self.port_str_map.insert(format!("{}:{}", info.local_ip, port), info);
    }
    
    // 清空所有数据
    pub fn clear(&mut self) {
        self.port_map.clear();
        self.port_str_map.clear();
    }
}

pub type SharedState = Arc<RwLock<NetAppState>>;

lazy_static::lazy_static! {
    pub static ref NETAPP_STATE: SharedState = Arc::new(RwLock::new(NetAppState::default()));
}

// 创建一个 trait 来扩展 SharedState 的功能
pub trait NetAppStateExt {
    fn print_state(&self);
    fn get_state_string(&self) -> String;
    fn add_port_info_to_state(&self, port: u16, info: PortBusinessInfo);
    fn get_port_info_from_state(&self, port: u16) -> Option<PortBusinessInfo>;
    fn clear_state(&self);
}

// 为 SharedState 实现这个 trait
impl NetAppStateExt for SharedState {
    fn print_state(&self) {
        if let Ok(state) = self.read() {
            state.print_contents();
        } else {
            println!("Failed to read NETAPP_STATE");
        }
    }
    
    fn get_state_string(&self) -> String {
        match self.read() {
            Ok(state) => state.get_contents_string(),
            Err(_) => "Failed to read NETAPP_STATE".to_string(),
        }
    }
    
    fn add_port_info_to_state(&self, port: u16, info: PortBusinessInfo) {
        if let Ok(mut state) = self.write() {
            state.add_port_info(port, info);
        }
    }
    
    fn get_port_info_from_state(&self, port: u16) -> Option<PortBusinessInfo> {
        match self.read() {
            Ok(state) => state.get_port_info(port).cloned(),
            Err(_) => None,
        }
    }
    
    fn clear_state(&self) {
        if let Ok(mut state) = self.write() {
            state.clear();
        }
    }
}

// 便捷函数
pub fn print_netapp_state() {
    NETAPP_STATE.print_state();
}

pub fn add_port_to_state(port: u16, info: PortBusinessInfo) {
    NETAPP_STATE.add_port_info_to_state(port, info);
}

pub fn get_port_from_state(port: u16) -> Option<PortBusinessInfo> {
    NETAPP_STATE.get_port_info_from_state(port)
}
